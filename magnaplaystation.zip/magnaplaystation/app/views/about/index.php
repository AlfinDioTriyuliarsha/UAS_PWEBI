<div class="container">
    <h1 class="mt-4">About Me</h1>
    <img src="<?= BASEURL ;?>/img/MyProfile.jpg" alt="Profil Saya" class="gambar">
    <img src="<?= BASEURL ;?>/img/Alfin.jpg" alt="Profil Saya" class="gambar">
    <img src="<?= BASEURL ;?>/img/Teguh.jpg" alt="Profil Saya" class="gambar">
    <p>Web Magna Playstation ialah website untuk pengelolaan penggunaan ps 3 dan 4. 
        <br>Dimana untuk mendata pengunjung yang bermain ps di magna playstation. web ini berisikan informasi data pelanggan terkait pelanggan yang memainkan ps</p>
</div> 

