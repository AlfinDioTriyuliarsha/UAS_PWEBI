
<div class="container">
    <!-- <div class="p-5 mt-3 bg-body-tertiary rounded-4">
        <h1 class="display-5 fw-bold ">CRUD Sederhana</h1>
        <p class="lead">Hallo, Nama Saya <= $_SESSION['username'] ?></p>
        <button class="btn btn-primary btn-lg" type="button">Example button</button>
    </div> -->

    <img src="<?= BASEURL ;?>/img/Magna.png" alt="bg" class="ps5">
</div>

