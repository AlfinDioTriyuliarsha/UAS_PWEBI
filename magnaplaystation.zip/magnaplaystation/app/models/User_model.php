<?php
class User_model {
    private $nama = 'Agus';

    public function getUser(){
        return $this->nama;
    }
}
